function calcularForcaMagnetica() {
    let carga = parseFloat(document.getElementById('carga').value);
    let velocidade = parseFloat(document.getElementById('velocidade').value);
    let campoMagnetico = parseFloat(document.getElementById('campoMagnetico').value);
    let angulo = parseFloat(document.getElementById('angulo').value);
 
    // Verificacao de entradas invalidas
    if (isNaN(carga) || isNaN(velocidade) || isNaN(campoMagnetico) || isNaN(angulo) || campoMagnetico <= 0 || velocidade <= 0) {
        document.getElementById('resultado').textContent = "Insira valores validos. A velocidade e o campo magnetico devem ser maiores que 0.";
        return;
    }
 
    // Conversao do angulo para radianos
    let anguloRad = angulo * (Math.PI / 180);
 
    // Calculo da forca magnetica com a formula F = q * v * B * sin(α)
    let forcaMagnetica = carga * velocidade * campoMagnetico * Math.sin(anguloRad);
 
    // Exibicao do resultado
    document.getElementById('resultado').textContent = `A forca magnetica e de ${forcaMagnetica.toFixed(2)} N`;
}